package com.example.futbol.Entity;

public enum Posicion {
    PORTERO, DEFENSA, MEDIO, DELANTERO
}
