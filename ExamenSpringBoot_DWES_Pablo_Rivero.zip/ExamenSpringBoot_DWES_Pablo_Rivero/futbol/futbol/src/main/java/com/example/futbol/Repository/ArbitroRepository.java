package com.example.futbol.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.futbol.Entity.Arbitro;

public interface ArbitroRepository extends JpaRepository<Arbitro, String>{
    

}
