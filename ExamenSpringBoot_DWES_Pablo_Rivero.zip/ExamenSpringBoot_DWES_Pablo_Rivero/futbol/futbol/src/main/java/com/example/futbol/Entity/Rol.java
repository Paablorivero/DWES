package com.example.futbol.Entity;

public enum Rol {
    PRINCIPAL, ASISTENTE
}
